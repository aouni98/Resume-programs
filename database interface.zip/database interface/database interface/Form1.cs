﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace database_interface
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void ordersBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.ordersBindingSource.EndEdit();
            this.ordersTableAdapter.Update(grocery_Store_InventoryDataSet.Orders);

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'grocery_Store_InventoryDataSet.Supplier' table. You can move, or remove it, as needed.
            this.supplierTableAdapter.Fill(this.grocery_Store_InventoryDataSet.Supplier);
            // TODO: This line of code loads data into the 'grocery_Store_InventoryDataSet.Products' table. You can move, or remove it, as needed.
            this.productsTableAdapter.Fill(this.grocery_Store_InventoryDataSet.Products);
            // TODO: This line of code loads data into the 'grocery_Store_InventoryDataSet.Orders' table. You can move, or remove it, as needed.
            this.ordersTableAdapter.Fill(this.grocery_Store_InventoryDataSet.Orders);

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void fillByToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.ordersTableAdapter.FillBy(this.grocery_Store_InventoryDataSet.Orders, ((int)(System.Convert.ChangeType(item_idToolStripTextBox.Text, typeof(int)))));
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void fillBy1ToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.ordersTableAdapter.FillBy1(this.grocery_Store_InventoryDataSet.Orders, ((int)(System.Convert.ChangeType(item_idToolStripTextBox.Text, typeof(int)))));
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void fillByToolStripButton_Click_1(object sender, EventArgs e)
        {
            try
            {
                this.productsTableAdapter.FillBy(this.grocery_Store_InventoryDataSet.Products, ((int)(System.Convert.ChangeType(idToolStripTextBox.Text, typeof(int)))));
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void fillByToolStrip_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void fillByToolStripButton1_Click(object sender, EventArgs e)
        {
            try
            {
                this.supplierTableAdapter.FillBy(this.grocery_Store_InventoryDataSet.Supplier, ((int)(System.Convert.ChangeType(idToolStripTextBox1.Text, typeof(int)))));
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void toolStripButton7_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.productsBindingSource.EndEdit();
            this.productsTableAdapter.Update(grocery_Store_InventoryDataSet.Products);
        }

        private void toolStripButton14_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.supplierBindingSource.EndEdit();
            this.supplierTableAdapter.Update(grocery_Store_InventoryDataSet.Supplier);
        }

        private void toolStripButton15_Click(object sender, EventArgs e)
        {
            this.ordersTableAdapter.Fill(this.grocery_Store_InventoryDataSet.Orders);
        }

        private void toolStripButton16_Click(object sender, EventArgs e)
        {
            this.productsTableAdapter.Fill(this.grocery_Store_InventoryDataSet.Products);
        }

        private void toolStripButton17_Click(object sender, EventArgs e)
        {
            this.supplierTableAdapter.Fill(this.grocery_Store_InventoryDataSet.Supplier);
        }

        private void fillBy2ToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.ordersTableAdapter.FillBy2(this.grocery_Store_InventoryDataSet.Orders, ((int)(System.Convert.ChangeType(supplier_idToolStripTextBox.Text, typeof(int)))));
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void fillBy1ToolStripButton1_Click(object sender, EventArgs e)
        {
            try
            {
                this.productsTableAdapter.FillBy1(this.grocery_Store_InventoryDataSet.Products, nameToolStripTextBox.Text);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void fillBy1ToolStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void fillBy1ToolStripButton2_Click(object sender, EventArgs e)
        {
            try
            {
                this.supplierTableAdapter.FillBy1(this.grocery_Store_InventoryDataSet.Supplier, nameToolStripTextBox1.Text);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void fillBydeliverydateToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.ordersTableAdapter.FillBydeliverydate(this.grocery_Store_InventoryDataSet.Orders, delivery_dateToolStripTextBox.Text);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void fillBy3ToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.ordersTableAdapter.FillBy3(this.grocery_Store_InventoryDataSet.Orders, order_dateToolStripTextBox.Text);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void fillBybrandnameToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.productsTableAdapter.FillBybrandname(this.grocery_Store_InventoryDataSet.Products, brandNameToolStripTextBox.Text);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void fillBybrandnameToolStrip_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void fillBy2ToolStripButton1_Click(object sender, EventArgs e)
        {
            try
            {
                this.productsTableAdapter.FillBy2(this.grocery_Store_InventoryDataSet.Products, new System.Nullable<int>(((int)(System.Convert.ChangeType(isle_NumToolStripTextBox.Text, typeof(int))))));
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void fillBy4ToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.ordersTableAdapter.FillBy4(this.grocery_Store_InventoryDataSet.Orders, ((int)(System.Convert.ChangeType(order_numberToolStripTextBox.Text, typeof(int)))));
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }
    }
}
